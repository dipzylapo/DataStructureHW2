#Ink 1113536 28/11
#pb1
class TreeNode:
    def __init__(self, val=0):
        self.val = val
        self.left = None
        self.right = None

class Solution:
    def build_tree(self, nums):
        """Build a binary tree from level-order traversal"""
        if not nums or nums[0] == -1:
            return None
        
        root = TreeNode(nums[0])
        queue = [root]
        i = 1
        
        while queue and i < len(nums):
            current = queue.pop(0)
            
            # Left child
            if i < len(nums) and nums[i] != -1:
                current.left = TreeNode(nums[i])
                queue.append(current.left)
            i += 1
            
            # Right child
            if i < len(nums) and nums[i] != -1:
                current.right = TreeNode(nums[i])
                queue.append(current.right)
            i += 1
        
        return root
    
    def calculate_diameter(self, root):
        """
        Calculate the diameter of the binary tree
        Returns a tuple (height, diameter)
        """
        if not root:
            return 0, 0
        
        left_height, left_diameter = self.calculate_diameter(root.left)
        right_height, right_diameter = self.calculate_diameter(root.right)
        
        current_diameter = max(
            left_diameter, 
            right_diameter, 
            left_height + right_height
        )
        
        return max(left_height, right_height) + 1, current_diameter
    
    def tree_diameter(self, nums):
        """Main function to find tree diameter"""
        root = self.build_tree(nums)
        _, diameter = self.calculate_diameter(root)
        return diameter

def main():
    # Example input
    input_nums = [1, 2, 3, 4, 5, -1, -1, -1, -1, 6, 7]
    sol = Solution()
    print("Diameter of the binary tree:", sol.tree_diameter(input_nums))

if __name__ == "__main__":
    main()
