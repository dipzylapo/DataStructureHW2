#Ink 1113536 28/11
#pb3
import heapq

class Solution:
    def merge_k_sorted_arrays(self, arrays):
        """
        Merge K sorted arrays using min priority queue
        """
        # Result array to store merged elements
        result = []
        
        # Min heap to track smallest elements
        min_heap = []
        
        # Insert first element from each array
        for i, arr in enumerate(arrays):
            if arr:
                # Store (value, array_index, element_index)
                heapq.heappush(min_heap, (arr[0], i, 0))
        
        # Merge process
        while min_heap:
            val, arr_idx, elem_idx = heapq.heappop(min_heap)
            
            # Add current smallest element to result
            result.append(val)
            
            # If more elements in the same array, push next element
            if elem_idx + 1 < len(arrays[arr_idx]):
                next_val = arrays[arr_idx][elem_idx + 1]
                heapq.heappush(min_heap, (next_val, arr_idx, elem_idx + 1))
        
        return result

def main():
    # Number of arrays
    K = int(input())
    
    # Input K sorted arrays
    arrays = []
    for _ in range(K):
        # Read each array from input
        arr = list(map(int, input().split()))
        arrays.append(arr)
    
    # Merge arrays
    sol = Solution()
    merged_array = sol.merge_k_sorted_arrays(arrays)
    
    # Print merged array
    print("Merged Array:", merged_array)

if __name__ == "__main__":
    main()
