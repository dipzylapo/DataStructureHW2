#Ink 1113536 28/11
#pb4
import heapq

class TaskScheduler:
    def schedule_tasks(self, tasks):
        """
        Schedule tasks to maximize profit while respecting deadlines
        
        Args:
        tasks (list): List of (profit, deadline) tuples
        
        Returns:
        tuple: (total_profit, scheduled_tasks)
        """
        
        tasks.sort(key=lambda x: x[1])
 
        max_heap = []
        slots = [0] * (len(tasks) + 1)
        scheduled_tasks = []
        total_profit = 0
        
        for profit, deadline in tasks:
            if slots[deadline] == 0:
                slots[deadline] = 1
                total_profit += profit
                scheduled_tasks.append(profit)
            else:
                scheduled = False
                for j in range(deadline - 1, 0, -1):
                    if slots[j] == 0:
                        slots[j] = 1
                        total_profit += profit
                        scheduled_tasks.append(profit)
                        scheduled = True
                        break
                
                if not scheduled:
                    heapq.heappush(max_heap, -profit)
        
        return total_profit, scheduled_tasks

def main():
    N = int(input())
    
    tasks = []
    for _ in range(N):
        profit, deadline = map(int, input().split())
        tasks.append((profit, deadline))
    
    scheduler = TaskScheduler()
    max_profit, scheduled_tasks = scheduler.schedule_tasks(tasks)
    
    print("Maximum Profit:", max_profit)
    print("Scheduled Tasks:", scheduled_tasks)

if __name__ == "__main__":
    main()
