#Ink 1113536 28/11
#pb2

import heapq

class TaskPriorityQueue:
    def __init__(self):
        self.pq = []
        self.tasks = []
    
    def add_task(self, task_name, priority):
        """Add a task to the priority queue"""
        heapq.heappush(self.pq, (-priority, task_name))
    
    def get_highest_priority_task(self):
        """Remove and return the highest priority task"""
        if not self.pq:
            return "No tasks"
     
        priority, task_name = heapq.heappop(self.pq)
        return task_name
    
    def display_remaining_tasks(self):
        """Display remaining tasks in descending order of priority"""
        remaining = [(task_name, -priority) for (priority, task_name) in self.pq]
        
        remaining.sort(key=lambda x: x[1], reverse=True)
        
        print("Remaining tasks:", remaining)

def main():
    N = int(input())
    tpq = TaskPriorityQueue()
    
    for _ in range(N):
        op = input().split()
        
        if op[0] == "ADD":
            
            tpq.add_task(op[1], int(op[2]))
        elif op[0] == "GET":
            
            print(tpq.get_highest_priority_task())
    
    tpq.display_remaining_tasks()

if __name__ == "__main__":
    main()